# Informe UX-Auditor · Ejemplo UX-Auditor v2.1

- **Fecha:** 2026-10-14T16:47:03\+02:00
- **IUX del sitio:** **5,99 / 10** (Aceptable) · peor página 4,18
- **Herramienta:** UX-Auditor 2.1.0 · reglas 2.1.0

## buena.html

**IUX: 8,90 / 10 — Buena** · cobertura 77,20 %

> ⛔ Techos aplicados (modo estricto); sin techos la nota sería 9,48:
> - «Excelente» exige una auditoría completa y sin fallos graves: 1 regla alta o crítica sin cumplir del todo; 21 reglas de evaluación experta sin responder; cobertura 77 % \(&lt; 90 %\). Nota máxima 8,9

| Dimensión | Peso | Nota |
|---|---:|---:|
| D1 Accesibilidad | 25,00 | 10,00 |
| D2 Usabilidad e interacción | 15,00 | 7,14 |
| D3 Rendimiento percibido | 15,00 | 10,00 |
| D4 Diseño visual y consistencia | 10,00 | 10,00 |
| D5 Formularios y feedback | 10,00 | 10,00 |
| D6 Navegación y arquitectura de la información | 10,00 | 10,00 |
| D7 Satisfacción percibida | 5,00 | 8,15 |
| D8 Ética, privacidad y sostenibilidad | 10,00 | 10,00 |

### Problemas (3)

- **[Media] INT-ESPACIADO · Separación entre objetivos táctiles \(≥ 8 px\)** — No cumple (10 de 12 elementos correctos)
  - Norma: Apple HIG · Material Design
  - Cómo corregirlo: Deja al menos 8 px entre controles pequeños.
  - [movil] html &gt; body &gt; header &gt; a.logo: a menos de 8 px de «Inicio»
  - [movil] header &gt; nav &gt; ul &gt; li:nth-of-type\(1\) &gt; a: a menos de 8 px de «La Marea, ir a la portada»
- **[Media] INT-OBJETIVO-TACTIL · Objetivos táctiles cómodos \(44×44 px\)** — No cumple (11 de 12 elementos correctos)
  - Norma: Apple HIG 44 pt · Material Design 48 dp · ley de Fitts
  - Cómo corregirlo: En móvil, botones y enlaces de navegación de al menos 44×44 px \(amplía el área con padding\).
  - [movil] html &gt; body &gt; header &gt; a.logo: 40×48 px «La Marea, ir a la portada»
- **[Alta] SAT-SUS · Satisfacción de usuarios \(SUS\)** — Cumple parcialmente (SUS 81.5/100 \(5 participantes\))
  - Norma: SUS \(Brooke\) · ISO 9241-11 satisfacción
  - Cómo corregirlo: Prueba con al menos 5 usuarios; una puntuación SUS ≥ 68 está por encima de la media.

> ℹ️ Reglas manuales sin evaluar: MAN-AYUDA, MAN-CANCELACION, MAN-CONSISTENCIA, MAN-CONTENIDO-HOVER, MAN-CONTROL-LIBERTAD, MAN-COSTES-OCULTOS, MAN-ESTADO-SISTEMA, MAN-FLEXIBILIDAD, MAN-GESTION-FOCO, MAN-HOVER, MAN-IA-TRANSPARENCIA, MAN-KRUG-BUENA-VOLUNTAD, MAN-KRUG-EVIDENTE, MAN-KRUG-PORTADA, MAN-KRUG-PRUEBAS, MAN-MINIMALISMO, MAN-MUNDO-REAL, MAN-PREVENCION-ERRORES, MAN-RECONOCER, MAN-RECUPERACION-ERRORES, MAN-RESUMEN-ERRORES. Ejecuta `uxaudit manual` para completarlas.

## trampas.html

**IUX: 4,90 / 10 — Deficiente** · cobertura 77,60 %

> ⛔ Techos aplicados (modo estricto); sin techos la nota sería 6,34:
> - Fallo crítico \(ETI-COOKIES-RECHAZO, ETI-PRESELECCION, ETI-RASTREO-PREVIO\): nota máxima 4,9
> - Incumplimiento de accesibilidad de severidad alta \(A11Y-CALIDAD-ALT, A11Y-FOCO-OCULTO, A11Y-MULTIMEDIA, A11Y-NOMBRE-EN-ETIQUETA\): nota máxima 6,9
> - «Excelente» exige una auditoría completa y sin fallos graves: 15 reglas altas o críticas sin cumplir del todo; 21 reglas de evaluación experta sin responder; cobertura 78 % \(&lt; 90 %\). Nota máxima 8,9

| Dimensión | Peso | Nota |
|---|---:|---:|
| D1 Accesibilidad | 25,00 | 7,95 |
| D2 Usabilidad e interacción | 15,00 | 1,88 |
| D3 Rendimiento percibido | 15,00 | 10,00 |
| D4 Diseño visual y consistencia | 10,00 | 8,50 |
| D5 Formularios y feedback | 10,00 | 6,67 |
| D6 Navegación y arquitectura de la información | 10,00 | 5,45 |
| D7 Satisfacción percibida | 5,00 | 8,15 |
| D8 Ética, privacidad y sostenibilidad | 10,00 | 1,05 |

### Problemas (24)

- **[Crítica] ETI-COOKIES-RECHAZO · Rechazar cookies tan fácil como aceptarlas** — No cumple (banner con «Aceptar» pero sin «Rechazar» en la primera capa)
  - Norma: AEPD Guía sobre cookies \(2023\) · RGPD art. 7 · Directrices EDPB 03/2022 sobre patrones engañosos
  - Cómo corregirlo: Botón «Rechazar» en la primera capa, al mismo nivel, con el mismo tamaño, color y tipo de letra que «Aceptar».
  - [movil] html &gt; body &gt; div.cookie: Botón «Aceptar todas» sin opción equivalente para rechazar
  - [escritorio] html &gt; body &gt; div.cookie: Botón «Aceptar todas» sin opción equivalente para rechazar
- **[Crítica] ETI-PRESELECCION · Sin casillas de consentimiento premarcadas** — No cumple (0 de 4 elementos correctos)
  - Norma: RGPD art. 4.11 y 7 · TJUE C-673/17 \(Planet49\) · DSA art. 25
  - Cómo corregirlo: Las casillas de newsletter, publicidad o cesión a terceros deben estar desmarcadas por defecto.
  - [movil] body &gt; main &gt; form &gt; label:nth-of-type\(3\) &gt; input: casilla premarcada: «quiero recibir la newsletter con ofertas de marketing»
  - [movil] body &gt; main &gt; form &gt; label:nth-of-type\(4\) &gt; input: casilla premarcada: «acepto ceder mis datos a terceros para publicidad»
  - [escritorio] body &gt; main &gt; form &gt; label:nth-of-type\(3\) &gt; input: casilla premarcada: «quiero recibir la newsletter con ofertas de marketing»
  - [escritorio] body &gt; main &gt; form &gt; label:nth-of-type\(4\) &gt; input: casilla premarcada: «acepto ceder mis datos a terceros para publicidad»
- **[Crítica] ETI-RASTREO-PREVIO · Sin rastreo antes del consentimiento** — No cumple (1 rastreadores o cookies de seguimiento antes de dar consentimiento)
  - Norma: LSSI art. 22.2 · Directiva ePrivacy art. 5.3 · RGPD art. 6 · Guía de cookies AEPD
  - Cómo corregirlo: No cargues analítica, píxeles de publicidad ni cookies no técnicas hasta que el usuario acepte.
  - [movil] https://www.googletagmanager.com/gtag/js?…: petición a googletagmanager.com antes de cualquier consentimiento
- **[Alta] A11Y-CALIDAD-ALT · Textos alternativos útiles \(no solo presentes\)** — No cumple (0 de 4 elementos correctos)
  - Norma: WCAG 2.2 · 1.1.1 Contenido no textual \(A\) · W3C Alt Decision Tree
  - Cómo corregirlo: Describe la información o función de la imagen en menos de 150 caracteres.
  - [movil] html &gt; body &gt; main &gt; img:nth-of-type\(1\): alt="IMG\_2034.jpg": parece un nombre de fichero
  - [movil] html &gt; body &gt; main &gt; img:nth-of-type\(2\): alt="imagen": es genérico y no describe la imagen
  - [escritorio] html &gt; body &gt; main &gt; img:nth-of-type\(1\): alt="IMG\_2034.jpg": parece un nombre de fichero
  - [escritorio] html &gt; body &gt; main &gt; img:nth-of-type\(2\): alt="imagen": es genérico y no describe la imagen
- **[Alta] A11Y-FOCO-OCULTO · El foco no queda tapado por elementos fijos** — No cumple (7 de 14 elementos correctos)
  - Norma: WCAG 2.2 · 2.4.11 Foco no oculto \(mínimo\)
  - Cómo corregirlo: Reserva espacio \(scroll-padding\) para cabeceras, banners de cookies y barras fijas.
  - [escritorio] html &gt; body &gt; main &gt; button.btn: el foco queda tapado por un elemento fijo \(«Añadir producto 23»\)
  - [escritorio] \#mail: el foco queda tapado por un elemento fijo \(«Correo electrónico»\)
  - [escritorio] \#tel: el foco queda tapado por un elemento fijo \(«Teléfono \(obligatorio\)»\)
  - [escritorio] body &gt; main &gt; form &gt; label:nth-of-type\(3\) &gt; input: el foco queda tapado por un elemento fijo \(«Quiero recibir la newsletter con ofertas»\)
  - [escritorio] body &gt; main &gt; form &gt; label:nth-of-type\(4\) &gt; input: el foco queda tapado por un elemento fijo \(«Acepto ceder mis datos a terceros para p»\)
- **[Alta] A11Y-MULTIMEDIA · Vídeo y audio controlables y subtitulados** — No cumple (0 de 2 elementos correctos)
  - Norma: WCAG 2.2 · 1.2.2 Subtítulos · 1.4.2 Control del audio · 2.2.2 Poner en pausa
  - Cómo corregirlo: Vídeos con controles, subtítulos \(&lt;track kind="captions"&gt;\) y sin reproducción automática con sonido.
  - [movil] html &gt; body &gt; main &gt; video: &lt;video&gt; se reproduce solo con sonido, se mueve sola sin controles para pausar, no tiene subtítulos \(&lt;track kind="captions"&gt;\)
  - [escritorio] html &gt; body &gt; main &gt; video: &lt;video&gt; se reproduce solo con sonido, se mueve sola sin controles para pausar, no tiene subtítulos \(&lt;track kind="captions"&gt;\)
- **[Alta] A11Y-NOMBRE-EN-ETIQUETA · El nombre accesible incluye el texto visible** — No cumple (0 de 2 elementos correctos)
  - Norma: WCAG 2.2 · 2.5.3 Etiqueta en el nombre \(A\)
  - Cómo corregirlo: Si un control tiene aria-label, debe empezar por \(o contener\) el texto que se ve, para que funcione el control por voz \(«pulsa Comprar»\).
  - [movil] html &gt; body &gt; main &gt; button.btn: texto visible «anadir a la cesta» no está en el nombre accesible «anadir producto 23»
  - [escritorio] html &gt; body &gt; main &gt; button.btn: texto visible «anadir a la cesta» no está en el nombre accesible «anadir producto 23»
- **[Alta] INT-ENLACES-DISTINGUIBLES · Lo que es clicable se ve que es clicable** — No cumple (2 de 4 elementos correctos)
  - Norma: Krug, No me hagas pensar, cap. 3 \(diseño de valla publicitaria\) · WCAG 2.2 · 1.4.1 Uso del color
  - Cómo corregirlo: Subraya los enlaces dentro del texto o diferéncialos con algo más que el color.
  - [movil] body &gt; main &gt; div.caja:nth-of-type\(2\) &gt; p &gt; a.plano: enlace «condiciones» sin subrayar y con contraste 1.00:1 respecto al texto \(mínimo 3:1\)
  - [escritorio] body &gt; main &gt; div.caja:nth-of-type\(2\) &gt; p &gt; a.plano: enlace «condiciones» sin subrayar y con contraste 1.00:1 respecto al texto \(mínimo 3:1\)
- **[Alta] INT-OBJETIVO-WCAG · Tamaño mínimo de objetivo \(24×24 px\)** — No cumple (23 de 26 elementos correctos)
  - Norma: WCAG 2.2 · 2.5.8 Tamaño del objetivo \(mínimo\)
  - Cómo corregirlo: Que cada objetivo mida al menos 24×24 px o tenga separación suficiente de los demás.
  - [movil] \#tel: 185×21 px «Teléfono \(obligatorio\)»
  - [escritorio] body &gt; main &gt; form &gt; label:nth-of-type\(3\) &gt; input: 422×20 px «Quiero recibir la newsletter con ofertas»
  - [escritorio] html &gt; body &gt; main &gt; form &gt; button.enlace:nth-of-type\(2\): 203×21 px «No, gracias, prefiero pagar más»
- **[Alta] FORM-OBLIGATORIOS · Campos obligatorios indicados visualmente y en el código** — No cumple (2 de 4 elementos correctos)
  - Norma: WCAG 2.2 · 3.3.2 Etiquetas o instrucciones · 1.3.1
  - Cómo corregirlo: Marca los campos obligatorios en la etiqueta \(«\(obligatorio\)» o \* con leyenda\) y añade required o aria-required.
  - [movil] \#mail: campo obligatorio sin indicarlo en la etiqueta \(«Correo electrónico»\)
  - [escritorio] \#mail: campo obligatorio sin indicarlo en la etiqueta \(«Correo electrónico»\)
- **[Alta] NAV-PRUEBA-TRONCO · Prueba del tronco de Krug \(¿qué sitio es, dónde estoy, qué secciones hay?\)** — No cumple (prueba del tronco: 2 de 4 preguntas respondidas a simple vista)
  - Norma: Krug, No me hagas pensar, cap. 6 \(trunk test\) · WCAG 2.4.8 Ubicación \(AAA\)
  - Cómo corregirlo: En cualquier página deben verse a simple vista el logotipo enlazado a la portada, el título de la página, las secciones principales, la sección actual marcada \(aria-current o migas de pan\) y, en sitios grandes, un buscador.
  - [movil] body: ¿Qué sitio es? Falta un logotipo o nombre del sitio enlazado a la portada en la cabecera
  - [movil] body: ¿Cuáles son las secciones principales? Falta una navegación principal visible
  - [escritorio] body: ¿Qué sitio es? Falta un logotipo o nombre del sitio enlazado a la portada en la cabecera
  - [escritorio] body: ¿Cuáles son las secciones principales? Falta una navegación principal visible
- **[Alta] ETI-CONFIRMSHAMING · Sin textos que culpabilicen al rechazar \(confirmshaming\)** — No cumple (0 de 2 elementos correctos)
  - Norma: DSA art. 25 · Directrices EDPB 03/2022 · Directiva 2005/29/CE \(prácticas comerciales desleales\)
  - Cómo corregirlo: Opciones neutras: «No, gracias» o «Ahora no».
  - [movil] html &gt; body &gt; main &gt; form &gt; button.enlace:nth-of-type\(2\): texto que culpabiliza al rechazar: «No, gracias, prefiero pagar más»
  - [escritorio] html &gt; body &gt; main &gt; form &gt; button.enlace:nth-of-type\(2\): texto que culpabiliza al rechazar: «No, gracias, prefiero pagar más»
- **[Media] INT-CTA-COMPITEN · Una llamada a la acción principal clara** — No cumple (4 llamadas a la acción con el mismo peso visual en la primera pantalla)
  - Norma: Ley de Hick-Hyman · Nielsen H8 · jerarquía visual
  - Cómo corregirlo: Destaca una sola acción principal por pantalla; el resto, como secundarias \(contorno o enlace\).
  - [movil] html &gt; body &gt; main &gt; div.hero:nth-of-type\(1\) &gt; a.btn:nth-of-type\(1\): CTA «comprar ya» compite con otras 3 iguales
  - [movil] html &gt; body &gt; main &gt; div.hero:nth-of-type\(1\) &gt; a.btn:nth-of-type\(2\): CTA «ver oferta» compite con otras 3 iguales
  - [movil] html &gt; body &gt; main &gt; div.hero:nth-of-type\(1\) &gt; a.btn:nth-of-type\(3\): CTA «regalar» compite con otras 3 iguales
  - [movil] html &gt; body &gt; main &gt; div.hero:nth-of-type\(1\) &gt; a.btn:nth-of-type\(4\): CTA «unete al club» compite con otras 3 iguales
  - [escritorio] html &gt; body &gt; main &gt; div.hero:nth-of-type\(1\) &gt; a.btn:nth-of-type\(1\): CTA «comprar ya» compite con otras 4 iguales
- **[Media] INT-ESPACIADO · Separación entre objetivos táctiles \(≥ 8 px\)** — No cumple (9 de 13 elementos correctos)
  - Norma: Apple HIG · Material Design
  - Cómo corregirlo: Deja al menos 8 px entre controles pequeños.
  - [movil] \#tel: a menos de 8 px de «Acepto ceder mis datos a terce»
  - [movil] body &gt; main &gt; form &gt; label:nth-of-type\(4\) &gt; input: a menos de 8 px de «Teléfono \(obligatorio\)»
  - [movil] html &gt; body &gt; main &gt; form &gt; button.btn:nth-of-type\(1\): a menos de 8 px de «No, gracias, prefiero pagar má»
  - [movil] html &gt; body &gt; main &gt; form &gt; button.enlace:nth-of-type\(2\): a menos de 8 px de «Suscribirme»
- **[Media] INT-OBJETIVO-TACTIL · Objetivos táctiles cómodos \(44×44 px\)** — No cumple (9 de 13 elementos correctos)
  - Norma: Apple HIG 44 pt · Material Design 48 dp · ley de Fitts
  - Cómo corregirlo: En móvil, botones y enlaces de navegación de al menos 44×44 px \(amplía el área con padding\).
  - [movil] \#mail: 185×21 px «Correo electrónico»
  - [movil] \#tel: 185×21 px «Teléfono \(obligatorio\)»
  - [movil] html &gt; body &gt; main &gt; form &gt; button.enlace:nth-of-type\(2\): 203×21 px «No, gracias, prefiero pagar más»
  - [movil] html &gt; body &gt; div.cookie &gt; a: 81×20 px «Configurar»
- **[Media] VIS-TEXTO-COGNITIVO · Texto sin justificar, sin bloques en mayúsculas ni cursiva larga** — No cumple (10 de 12 elementos correctos)
  - Norma: WCAG 2.2 · 1.4.8 Presentación visual \(AAA\) · W3C COGA · guía de estilo de dislexia \(BDA\)
  - Cómo corregirlo: Alinea el texto a la izquierda y reserva las mayúsculas y la cursiva para textos muy cortos.
  - [movil] html &gt; body &gt; main &gt; p.legal:nth-of-type\(5\): texto justificado \(ríos de espacios\), bloque largo en MAYÚSCULAS: «AL CONTINUAR ACEPTAS QUE TUS DATOS SE UTILICEN PAR»
  - [escritorio] html &gt; body &gt; main &gt; p.legal:nth-of-type\(5\): texto justificado \(ríos de espacios\), bloque largo en MAYÚSCULAS: «AL CONTINUAR ACEPTAS QUE TUS DATOS SE UTILICEN PAR»
- **[Media] FORM-FORMATO-LIBRE · No castiga al usuario por escribir los datos a su manera** — No cumple (0 de 2 elementos correctos)
  - Norma: Krug, No me hagas pensar, cap. 11 \(reserva de buena voluntad\) · Nielsen H5 · WCAG 3.3.3
  - Cómo corregirlo: Acepta espacios, guiones y prefijos en teléfonos, tarjetas e IBAN y límpialos en el servidor.
  - [movil] \#tel: teléfono: el patrón rechaza «600 123 456» con espacios o guiones; maxlength=9 no deja escribir «600 123 456»
  - [escritorio] \#tel: teléfono: el patrón rechaza «600 123 456» con espacios o guiones; maxlength=9 no deja escribir «600 123 456»
- **[Media] NAV-ANCLAS-ROTAS · Enlaces internos con destino válido** — No cumple (0 de 12 elementos correctos)
  - Norma: HTML · Nielsen H4
  - Cómo corregirlo: Que cada href="\#id" apunte a un id existente; usa &lt;button&gt; para acciones.
  - [movil] html &gt; body &gt; main &gt; div.hero:nth-of-type\(1\) &gt; a.btn:nth-of-type\(1\): destino «\#comprar» inexistente
  - [movil] html &gt; body &gt; main &gt; div.hero:nth-of-type\(1\) &gt; a.btn:nth-of-type\(2\): destino «\#oferta» inexistente
  - [movil] html &gt; body &gt; main &gt; div.hero:nth-of-type\(1\) &gt; a.btn:nth-of-type\(3\): destino «\#regalo» inexistente
  - [movil] html &gt; body &gt; main &gt; div.hero:nth-of-type\(1\) &gt; a.btn:nth-of-type\(4\): destino «\#club» inexistente
  - [movil] body &gt; main &gt; div.caja:nth-of-type\(2\) &gt; p &gt; a.plano: destino «\#condiciones» inexistente
- **[Media] ETI-URGENCIA · Sin urgencia o escasez artificial** — No cumple (4 elementos de urgencia o escasez \(posible patrón oscuro: verifica que son reales\))
  - Norma: Directiva 2005/29/CE anexo I \(7\) · barrido de la Comisión Europea 2023 \(42 tiendas con temporizadores falsos\)
  - Cómo corregirlo: Muestra plazos y existencias solo si son reales y verificables.
  - [movil] html &gt; body &gt; main &gt; p:nth-of-type\(4\): cuenta atrás: «La oferta termina en 00:09:30» → «La oferta termina en 00:09:27»
  - [movil] \#reloj: cuenta atrás: «00:09:30» → «00:09:27»
  - [movil] html &gt; body &gt; main &gt; p:nth-of-type\(3\): mensaje de presión: «¡Date prisa\! Solo quedan 2 unidades. 17 personas están viendo este producto ahor»
  - [movil] html &gt; body &gt; main &gt; p:nth-of-type\(4\): mensaje de presión: «La oferta termina en 00:09:27»
- **[Baja] INT-CURSOR · Cursor de mano en elementos clicables** — No cumple (9 de 10 elementos correctos)
  - Norma: Guía UI UX Pro Max \(cursor-pointer\)
  - Cómo corregirlo: Aplica cursor:pointer a botones y controles clicables.
  - [escritorio] html &gt; body &gt; main &gt; form &gt; button.enlace:nth-of-type\(2\): cursor: default en «No, gracias, prefiero pagar más»
- **[Baja] VIS-PALABRAS-INNECESARIAS · Sin palabras innecesarias \(texto de bienvenida e instrucciones\)** — No cumple (2 fragmentos de texto innecesario \(Krug: «omite las palabras innecesarias»\))
  - Norma: Krug, No me hagas pensar, cap. 5 \(omite las palabras innecesarias\) · ISO 24495-1
  - Cómo corregirlo: Elimina la mitad de las palabras de cada página y luego la mitad de lo que quede; ve directo a la información.
  - [movil] html &gt; body &gt; main &gt; p:nth-of-type\(1\): texto de bienvenida que no aporta información: «Bienvenido a nuestra tienda online, nos complace ofrecerte los mejores»
  - [movil] html &gt; body &gt; main &gt; p:nth-of-type\(2\): instrucciones innecesarias: «Para continuar, haga clic en el botón de abajo y siga las instruccione»
  - [escritorio] html &gt; body &gt; main &gt; p:nth-of-type\(1\): texto de bienvenida que no aporta información: «Bienvenido a nuestra tienda online, nos complace ofrecerte los mejores»
  - [escritorio] html &gt; body &gt; main &gt; p:nth-of-type\(2\): instrucciones innecesarias: «Para continuar, haga clic en el botón de abajo y siga las instruccione»
- **[Alta] A11Y-CONTRASTE · Contraste de color del texto** — Cumple parcialmente (48 de 50 elementos correctos)
  - Norma: WCAG 2.2 · 1.4.3 Contraste \(mínimo\)
  - Cómo corregirlo: Asegura un contraste de al menos 4,5:1 en texto normal y 3:1 en texto grande \(≥ 24 px o ≥ 18,66 px en negrita\).
  - [movil] .cookie &gt; button\[type="button"\]: Elements must meet minimum color contrast ratio thresholds — Fix any of the following: Element has insufficient color contrast of 3.29 \(foreground color: \#ffffff, background color: \#16a34a, font size: 12.0pt \(16px\), font weight: normal\). Expected contrast rati…
  - [escritorio] .cookie &gt; button\[type="button"\]: Elements must meet minimum color contrast ratio thresholds — Fix any of the following: Element has insufficient color contrast of 3.29 \(foreground color: \#ffffff, background color: \#16a34a, font size: 12.0pt \(16px\), font weight: normal\). Expected contrast rati…
- **[Alta] A11Y-ESPACIADO-TEXTO · Soporta el espaciado de texto del usuario** — Cumple parcialmente (45 de 46 elementos correctos)
  - Norma: WCAG 2.2 · 1.4.12 Espaciado del texto \(AA\)
  - Cómo corregirlo: Usa alturas automáticas \(min-height en lugar de height\) para que el texto pueda crecer sin cortarse con interlineado 1,5, espaciado entre letras 0,12 em, entre palabras 0,16 em y entre párrafos 2 em.
  - [movil] html &gt; body &gt; main &gt; div.caja:nth-of-type\(2\): texto cortado o solapado: 136px de contenido en 91px \(«Envío gratuito a partir de 50 euros en p»\)
- **[Alta] SAT-SUS · Satisfacción de usuarios \(SUS\)** — Cumple parcialmente (SUS 81.5/100 \(5 participantes\))
  - Norma: SUS \(Brooke\) · ISO 9241-11 satisfacción
  - Cómo corregirlo: Prueba con al menos 5 usuarios; una puntuación SUS ≥ 68 está por encima de la media.

> ℹ️ Reglas manuales sin evaluar: MAN-AYUDA, MAN-CANCELACION, MAN-CONSISTENCIA, MAN-CONTENIDO-HOVER, MAN-CONTROL-LIBERTAD, MAN-COSTES-OCULTOS, MAN-ESTADO-SISTEMA, MAN-FLEXIBILIDAD, MAN-GESTION-FOCO, MAN-HOVER, MAN-IA-TRANSPARENCIA, MAN-KRUG-BUENA-VOLUNTAD, MAN-KRUG-EVIDENTE, MAN-KRUG-PORTADA, MAN-KRUG-PRUEBAS, MAN-MINIMALISMO, MAN-MUNDO-REAL, MAN-PREVENCION-ERRORES, MAN-RECONOCER, MAN-RECUPERACION-ERRORES, MAN-RESUMEN-ERRORES. Ejecuta `uxaudit manual` para completarlas.

## mala.html

**IUX: 4,18 / 10 — Deficiente** · cobertura 76,30 %

> ⛔ Techos aplicados (modo estricto); sin techos la nota sería 4,18:
> - Fallo crítico \(A11Y-REFLOW, FORM-PEGAR\): nota máxima 4,9
> - Incumplimiento de accesibilidad de severidad alta \(A11Y-ALT, A11Y-ALTO-CONTRASTE, A11Y-ETIQUETAS, A11Y-FOCO-VISIBLE, A11Y-IDIOMA, A11Y-MOVIMIENTO, A11Y-TAMANO-USUARIO, A11Y-ZOOM\): nota máxima 6,9
> - «Excelente» exige una auditoría completa y sin fallos graves: 21 reglas altas o críticas sin cumplir del todo; 21 reglas de evaluación experta sin responder; cobertura 76 % \(&lt; 90 %\). Nota máxima 8,9

| Dimensión | Peso | Nota |
|---|---:|---:|
| D1 Accesibilidad | 25,00 | 5,00 |
| D2 Usabilidad e interacción | 15,00 | 0,00 |
| D3 Rendimiento percibido | 15,00 | 8,46 |
| D4 Diseño visual y consistencia | 10,00 | 2,00 |
| D5 Formularios y feedback | 10,00 | 0,00 |
| D6 Navegación y arquitectura de la información | 10,00 | 0,53 |
| D7 Satisfacción percibida | 5,00 | 8,15 |
| D8 Ética, privacidad y sostenibilidad | 10,00 | 10,00 |

### Problemas (42)

- **[Crítica] A11Y-REFLOW · Reflujo a 320 px sin scroll horizontal** — No cumple (ancho del contenido 1200 px a 320 px)
  - Norma: WCAG 2.2 · 1.4.10 Reflujo
  - Cómo corregirlo: Diseño fluido \(porcentajes, flex/grid, max-width:100%\) que se adapte a 320 px de ancho.
  - [320px] html &gt; body &gt; div.wrap:nth-of-type\(1\): &lt;div&gt; termina en 1200 px \(ancho 1200 px\)
- **[Crítica] FORM-PEGAR · Se permite pegar en contraseñas y correos** — No cumple (0 de 2 elementos correctos)
  - Norma: WCAG 2.2 · 3.3.8 Autenticación accesible \(mínimo\)
  - Cómo corregirlo: Permite pegar y los gestores de contraseñas.
  - [movil] html &gt; body &gt; div.wrap:nth-of-type\(1\) &gt; form &gt; input:nth-of-type\(2\): se bloquea pegar en el campo password
  - [escritorio] html &gt; body &gt; div.wrap:nth-of-type\(1\) &gt; form &gt; input:nth-of-type\(2\): se bloquea pegar en el campo password
- **[Alta] A11Y-ALT · Texto alternativo en imágenes** — No cumple (6 de 8 elementos correctos)
  - Norma: WCAG 2.2 · 1.1.1 Contenido no textual
  - Cómo corregirlo: Describe en el atributo alt la función o el contenido de cada imagen significativa; usa alt="" en las decorativas.
  - [movil] img:nth-child\(7\): Images must have alternative text — Fix any of the following: Element does not have an alt attribute aria-label attribute does not exist or is empty aria-labelledby attribute does not exist, references elements that do not exist or ref…
  - [escritorio] img:nth-child\(7\): Images must have alternative text — Fix any of the following: Element does not have an alt attribute aria-label attribute does not exist or is empty aria-labelledby attribute does not exist, references elements that do not exist or ref…
- **[Alta] A11Y-ALTO-CONTRASTE · Foco visible en modo de alto contraste \(colores forzados\)** — No cumple (2 de 24 elementos correctos)
  - Norma: WCAG 2.2 · 2.4.7 Foco visible · 1.4.11 Contraste no textual · CSS forced-colors
  - Cómo corregirlo: Usa outline \(con outline-color transparent si hace falta\) en lugar de solo box-shadow o cambios de fondo, que desaparecen en el modo de alto contraste de Windows.
  - [escritorio] div.wrap:nth-of-type\(1\) &gt; nav &gt; ul &gt; li:nth-of-type\(1\) &gt; a: en alto contraste: sin indicador visible de foco \(«Uno»\)
  - [escritorio] div.wrap:nth-of-type\(1\) &gt; nav &gt; ul &gt; li:nth-of-type\(2\) &gt; a: en alto contraste: sin indicador visible de foco \(«Dos»\)
  - [escritorio] div.wrap:nth-of-type\(1\) &gt; nav &gt; ul &gt; li:nth-of-type\(3\) &gt; a: en alto contraste: sin indicador visible de foco \(«Tres»\)
  - [escritorio] div.wrap:nth-of-type\(1\) &gt; nav &gt; ul &gt; li:nth-of-type\(4\) &gt; a: en alto contraste: sin indicador visible de foco \(«Cuatro»\)
  - [escritorio] div.wrap:nth-of-type\(1\) &gt; nav &gt; ul &gt; li:nth-of-type\(5\) &gt; a: en alto contraste: sin indicador visible de foco \(«Cinco»\)
- **[Alta] A11Y-ETIQUETAS · Campos de formulario etiquetados** — No cumple (22 de 26 elementos correctos)
  - Norma: WCAG 2.2 · 1.3.1 / 3.3.2 Etiquetas o instrucciones
  - Cómo corregirlo: Asocia cada campo con un &lt;label for="id"&gt; o envuélvelo en un &lt;label&gt;.
  - [movil] input\[value="a"\]: Form elements must have labels — Fix any of the following: Element does not have an implicit \(wrapped\) &lt;label&gt; Element does not have an explicit &lt;label&gt; aria-label attribute does not exist or is empty aria-labelledby attribute does …
  - [movil] input\[value="b"\]: Form elements must have labels — Fix any of the following: Element does not have an implicit \(wrapped\) &lt;label&gt; Element does not have an explicit &lt;label&gt; aria-label attribute does not exist or is empty aria-labelledby attribute does …
  - [escritorio] input\[value="a"\]: Form elements must have labels — Fix any of the following: Element does not have an implicit \(wrapped\) &lt;label&gt; Element does not have an explicit &lt;label&gt; aria-label attribute does not exist or is empty aria-labelledby attribute does …
  - [escritorio] input\[value="b"\]: Form elements must have labels — Fix any of the following: Element does not have an implicit \(wrapped\) &lt;label&gt; Element does not have an explicit &lt;label&gt; aria-label attribute does not exist or is empty aria-labelledby attribute does …
- **[Alta] A11Y-FOCO-VISIBLE · Foco visible al navegar con teclado** — No cumple (0 de 24 elementos correctos)
  - Norma: WCAG 2.2 · 2.4.7 Foco visible
  - Cómo corregirlo: Muestra un indicador claro \(contorno de 2–4 px con contraste 3:1\) con :focus-visible.
  - [escritorio] div.wrap:nth-of-type\(1\) &gt; nav &gt; ul &gt; li:nth-of-type\(1\) &gt; a: sin indicador visible de foco \(«Uno»\)
  - [escritorio] div.wrap:nth-of-type\(1\) &gt; nav &gt; ul &gt; li:nth-of-type\(2\) &gt; a: sin indicador visible de foco \(«Dos»\)
  - [escritorio] div.wrap:nth-of-type\(1\) &gt; nav &gt; ul &gt; li:nth-of-type\(3\) &gt; a: sin indicador visible de foco \(«Tres»\)
  - [escritorio] div.wrap:nth-of-type\(1\) &gt; nav &gt; ul &gt; li:nth-of-type\(4\) &gt; a: sin indicador visible de foco \(«Cuatro»\)
  - [escritorio] div.wrap:nth-of-type\(1\) &gt; nav &gt; ul &gt; li:nth-of-type\(5\) &gt; a: sin indicador visible de foco \(«Cinco»\)
- **[Alta] A11Y-IDIOMA · Idioma de la página declarado** — No cumple (0 de 2 elementos correctos)
  - Norma: WCAG 2.2 · 3.1.1 Idioma de la página
  - Cómo corregirlo: Declara el idioma en &lt;html lang="es"&gt;.
  - [movil] html: &lt;html&gt; element must have a lang attribute — Fix any of the following: The &lt;html&gt; element does not have a lang attribute
  - [escritorio] html: &lt;html&gt; element must have a lang attribute — Fix any of the following: The &lt;html&gt; element does not have a lang attribute
- **[Alta] A11Y-MOVIMIENTO · Respeta «reducir movimiento»** — No cumple (1 animaciones → 1 con «reducir movimiento»)
  - Norma: WCAG 2.2 · 2.3.3 Animación por interacción / Apple Reduced Motion
  - Cómo corregirlo: Desactiva o reduce las animaciones con @media \(prefers-reduced-motion: reduce\).
  - [movil] document: 1 de 1 animaciones siguen activas con prefers-reduced-motion
- **[Alta] A11Y-TAMANO-USUARIO · Respeta el tamaño de letra elegido por el usuario** — No cumple (con la letra del navegador al 200 %, el texto pasa de 13 px a 13 px \(×1.00\))
  - Norma: WCAG 2.2 · 1.4.4 Cambio de tamaño del texto \(AA\) · Apple Dynamic Type
  - Cómo corregirlo: Define los tamaños de letra en rem o em \(font-size: 100% en html\) para que escalen con la preferencia del navegador.
  - [escritorio] html: Los tamaños de letra en px no escalan con la preferencia del usuario
- **[Alta] A11Y-ZOOM · Zoom permitido** — No cumple (2 de 4 elementos correctos)
  - Norma: WCAG 2.2 · 1.4.4 Cambio de tamaño del texto
  - Cómo corregirlo: Usa &lt;meta name="viewport" content="width=device-width, initial-scale=1"&gt;.
  - [movil] meta: Zooming and scaling must not be disabled — Fix any of the following: user-scalable=no on &lt;meta&gt; tag disables zooming on mobile devices
  - [escritorio] meta: Zooming and scaling must not be disabled — Fix any of the following: user-scalable=no on &lt;meta&gt; tag disables zooming on mobile devices
- **[Alta] INT-CLIC-NO-SEMANTICO · Elementos clicables sin semántica de control** — No cumple (50 de 62 elementos correctos)
  - Norma: WCAG 2.2 · 2.1.1 / 4.1.2 · ISO 9241-110 conformidad con expectativas
  - Cómo corregirlo: Usa &lt;button&gt; o &lt;a href&gt; para todo lo que responde a un clic.
  - [movil] html &gt; body &gt; div.wrap:nth-of-type\(1\) &gt; div.menu:nth-of-type\(1\) &gt; span:nth-of-type\(1\): &lt;span&gt; con onclick sin role ni tabindex \(«Inicio»\)
  - [movil] html &gt; body &gt; div.wrap:nth-of-type\(1\) &gt; div.menu:nth-of-type\(1\) &gt; span:nth-of-type\(2\): &lt;span&gt; con onclick sin role ni tabindex \(«Productos»\)
  - [movil] html &gt; body &gt; div.wrap:nth-of-type\(1\) &gt; div.menu:nth-of-type\(1\) &gt; span:nth-of-type\(3\): &lt;span&gt; con onclick sin role ni tabindex \(«Ofertas»\)
  - [movil] html &gt; body &gt; div.wrap:nth-of-type\(1\) &gt; div.menu:nth-of-type\(1\) &gt; span:nth-of-type\(4\): &lt;span&gt; con onclick sin role ni tabindex \(«Blog»\)
  - [movil] html &gt; body &gt; div.wrap:nth-of-type\(1\) &gt; div.menu:nth-of-type\(1\) &gt; span:nth-of-type\(5\): &lt;span&gt; con onclick sin role ni tabindex \(«Contacto»\)
- **[Alta] INT-OBJETIVO-WCAG · Tamaño mínimo de objetivo \(24×24 px\)** — No cumple (28 de 50 elementos correctos)
  - Norma: WCAG 2.2 · 2.5.8 Tamaño del objetivo \(mínimo\)
  - Cómo corregirlo: Que cada objetivo mida al menos 24×24 px o tenga separación suficiente de los demás.
  - [movil] div.wrap:nth-of-type\(1\) &gt; nav &gt; ul &gt; li:nth-of-type\(1\) &gt; a: 24×15 px «Uno»
  - [movil] div.wrap:nth-of-type\(1\) &gt; nav &gt; ul &gt; li:nth-of-type\(2\) &gt; a: 23×15 px «Dos»
  - [movil] div.wrap:nth-of-type\(1\) &gt; nav &gt; ul &gt; li:nth-of-type\(3\) &gt; a: 26×15 px «Tres»
  - [movil] div.wrap:nth-of-type\(1\) &gt; nav &gt; ul &gt; li:nth-of-type\(4\) &gt; a: 39×15 px «Cuatro»
  - [movil] div.wrap:nth-of-type\(1\) &gt; nav &gt; ul &gt; li:nth-of-type\(5\) &gt; a: 33×15 px «Cinco»
- **[Alta] VIS-DESBORDAMIENTO · Sin scroll horizontal en el viewport** — No cumple (1 de 2 elementos correctos)
  - Norma: Guía UI UX Pro Max \(Horizontal Scroll\)
  - Cómo corregirlo: Contenedores con max-width:100% y diseño adaptable.
  - [movil] html &gt; body &gt; div.wrap:nth-of-type\(1\): &lt;div&gt; termina en 1200 px \(ancho 1200 px\)
- **[Alta] VIS-RESPONSIVE-INTERMEDIO · Sin roturas en tamaños intermedios \(tablet, móvil horizontal\)** — No cumple (1 de 5 tamaños sin desbordamiento)
  - Norma: WCAG 2.2 · 1.4.10 Reflujo · Guía UI UX Pro Max \(Breakpoint Testing\)
  - Cómo corregirlo: Prueba y corrige los anchos 600, 768, 1024 y 1280 px y el móvil en horizontal.
  - [varios] html &gt; body &gt; div.wrap:nth-of-type\(1\): a 600px: el contenido mide 1200 px en 600 px. &lt;div&gt; termina en 1200 px \(ancho 1200 px\)
  - [varios] html &gt; body &gt; div.wrap:nth-of-type\(1\): a 768px: el contenido mide 1200 px en 768 px. &lt;div&gt; termina en 1200 px \(ancho 1200 px\)
  - [varios] html &gt; body &gt; div.wrap:nth-of-type\(1\): a 1024px: el contenido mide 1200 px en 1024 px. &lt;div&gt; termina en 1200 px \(ancho 1200 px\)
  - [varios] html &gt; body &gt; div.wrap:nth-of-type\(1\): a móvil horizontal: el contenido mide 1200 px en 812 px. &lt;div&gt; termina en 1200 px \(ancho 1200 px\)
- **[Alta] VIS-TAM-TEXTO · Texto de al menos 12 px** — No cumple (44 de 60 elementos correctos)
  - Norma: Guía UI UX Pro Max \(Typography &amp; Color\)
  - Cómo corregirlo: Ningún texto por debajo de 12 px.
  - [movil] html &gt; body &gt; div.wrap:nth-of-type\(1\) &gt; p.mini:nth-of-type\(2\): 9.0 px: «Aviso legal en letra diminuta que nadie puede leer»
  - [movil] html &gt; body &gt; div.sticky:nth-of-type\(2\) &gt; a:nth-of-type\(1\): 10.0 px: «Inicio»
  - [movil] html &gt; body &gt; div.sticky:nth-of-type\(2\) &gt; a:nth-of-type\(2\): 10.0 px: «Buscar»
  - [movil] html &gt; body &gt; div.sticky:nth-of-type\(2\) &gt; a:nth-of-type\(3\): 10.0 px: «Carrito»
  - [movil] html &gt; body &gt; div.sticky:nth-of-type\(2\) &gt; a:nth-of-type\(4\): 10.0 px: «Favoritos»
- **[Alta] FORM-ETIQUETA-VISIBLE · Etiquetas visibles \(no solo placeholder\)** — No cumple (0 de 4 elementos correctos)
  - Norma: WCAG 2.2 · 3.3.2 · GOV.UK Design System
  - Cómo corregirlo: Etiqueta visible encima de cada campo.
  - [movil] html &gt; body &gt; div.wrap:nth-of-type\(1\) &gt; form &gt; input:nth-of-type\(1\): solo placeholder «Tu email»
  - [movil] html &gt; body &gt; div.wrap:nth-of-type\(1\) &gt; form &gt; input:nth-of-type\(2\): solo placeholder «Contraseña»
  - [escritorio] html &gt; body &gt; div.wrap:nth-of-type\(1\) &gt; form &gt; input:nth-of-type\(1\): solo placeholder «Tu email»
  - [escritorio] html &gt; body &gt; div.wrap:nth-of-type\(1\) &gt; form &gt; input:nth-of-type\(2\): solo placeholder «Contraseña»
- **[Alta] NAV-CONSISTENCIA · Navegación y ayuda consistentes entre páginas** — No cumple (menú de 9 enlaces · 0% en común con la página de referencia)
  - Norma: WCAG 2.2 · 3.2.3 Navegación coherente · 3.2.4 Identificación coherente · 3.2.6 Ayuda consistente
  - Cómo corregirlo: Mantén el mismo menú, en el mismo orden, y el enlace de ayuda/contacto en el mismo sitio en todas las páginas.
  - [sitio] nav: solo comparte el 0% del menú con «Reservas · Restaurante La Marea»
  - [sitio] nav: falta el enlace de ayuda/contacto que sí hay en otras páginas
- **[Alta] NAV-PRUEBA-TRONCO · Prueba del tronco de Krug \(¿qué sitio es, dónde estoy, qué secciones hay?\)** — No cumple (prueba del tronco: 1 de 4 preguntas respondidas a simple vista)
  - Norma: Krug, No me hagas pensar, cap. 6 \(trunk test\) · WCAG 2.4.8 Ubicación \(AAA\)
  - Cómo corregirlo: En cualquier página deben verse a simple vista el logotipo enlazado a la portada, el título de la página, las secciones principales, la sección actual marcada \(aria-current o migas de pan\) y, en sitios grandes, un buscador.
  - [movil] body: ¿Qué sitio es? Falta un logotipo o nombre del sitio enlazado a la portada en la cabecera
  - [movil] body: ¿En qué página estoy? Falta un título de página visible \(h1\)
  - [movil] body: ¿Dónde estoy? El menú no marca la sección actual \(aria-current\) ni hay migas de pan
  - [escritorio] body: ¿Qué sitio es? Falta un logotipo o nombre del sitio enlazado a la portada en la cabecera
  - [escritorio] body: ¿En qué página estoy? Falta un título de página visible \(h1\)
- **[Media] A11Y-AXE-OTRAS · Otras incidencias de accesibilidad \(axe-core\)** — No cumple (136 de 160 elementos correctos)
  - Norma: WCAG 2.2 \(varios criterios\)
  - Cómo corregirlo: Revisa cada incidencia y aplica la corrección indicada por axe-core.
  - [movil] html: Document should have one main landmark — Fix all of the following: Document does not have a main landmark
  - [movil] .wrap: All page content should be contained by landmarks — Fix any of the following: Some page content is not contained by landmarks
  - [movil] .sticky: All page content should be contained by landmarks — Fix any of the following: Some page content is not contained by landmarks
  - [movil] li:nth-child\(1\) &gt; a\[href="\#"\]: All touch targets must be 24px large, or leave sufficient space — Fix any of the following: Target has insufficient size \(23.9px by 15px, should be at least 24px by 24px\) Target has insufficient space to its closest neighbors. Safe clickable space has a diameter of…
  - [movil] li:nth-child\(2\) &gt; a\[href="\#"\]: All touch targets must be 24px large, or leave sufficient space — Fix any of the following: Target has insufficient size \(23.1px by 15px, should be at least 24px by 24px\) Target has insufficient space to its closest neighbors. Safe clickable space has a diameter of…
- **[Media] A11Y-ENCABEZADOS · Jerarquía de encabezados** — No cumple (8 de 10 elementos correctos)
  - Norma: WCAG 2.2 · 1.3.1 / 2.4.6 Encabezados y etiquetas
  - Cómo corregirlo: Un único h1 y niveles consecutivos \(h1 → h2 → h3\) que describan el contenido.
  - [movil] html: Page should contain a level-one heading — Fix all of the following: Page must have a level-one heading
  - [escritorio] html: Page should contain a level-one heading — Fix all of the following: Page must have a level-one heading
- **[Media] INT-ESPACIADO · Separación entre objetivos táctiles \(≥ 8 px\)** — No cumple (19 de 25 elementos correctos)
  - Norma: Apple HIG · Material Design
  - Cómo corregirlo: Deja al menos 8 px entre controles pequeños.
  - [movil] html &gt; body &gt; div.wrap:nth-of-type\(1\) &gt; a:nth-of-type\(1\): a menos de 8 px de «Contraseña»
  - [movil] html &gt; body &gt; div.wrap:nth-of-type\(1\) &gt; a:nth-of-type\(3\): a menos de 8 px de «✖»
  - [movil] html &gt; body &gt; div.wrap:nth-of-type\(1\) &gt; button:nth-of-type\(1\): a menos de 8 px de «Leer más»
  - [movil] html &gt; body &gt; div.wrap:nth-of-type\(1\) &gt; button.icon:nth-of-type\(2\): a menos de 8 px de «✖»
  - [movil] html &gt; body &gt; div.wrap:nth-of-type\(1\) &gt; form &gt; input:nth-of-type\(1\): a menos de 8 px de «Contraseña»
- **[Media] INT-OBJETIVO-TACTIL · Objetivos táctiles cómodos \(44×44 px\)** — No cumple (7 de 25 elementos correctos)
  - Norma: Apple HIG 44 pt · Material Design 48 dp · ley de Fitts
  - Cómo corregirlo: En móvil, botones y enlaces de navegación de al menos 44×44 px \(amplía el área con padding\).
  - [movil] div.wrap:nth-of-type\(1\) &gt; nav &gt; ul &gt; li:nth-of-type\(1\) &gt; a: 24×15 px «Uno»
  - [movil] div.wrap:nth-of-type\(1\) &gt; nav &gt; ul &gt; li:nth-of-type\(2\) &gt; a: 23×15 px «Dos»
  - [movil] div.wrap:nth-of-type\(1\) &gt; nav &gt; ul &gt; li:nth-of-type\(3\) &gt; a: 26×15 px «Tres»
  - [movil] div.wrap:nth-of-type\(1\) &gt; nav &gt; ul &gt; li:nth-of-type\(4\) &gt; a: 39×15 px «Cuatro»
  - [movil] div.wrap:nth-of-type\(1\) &gt; nav &gt; ul &gt; li:nth-of-type\(5\) &gt; a: 33×15 px «Cinco»
- **[Media] PERF-IMG-DIMENSIONES · Imágenes con dimensiones reservadas** — No cumple (2 de 4 elementos correctos)
  - Norma: Core Web Vitals · CLS
  - Cómo corregirlo: Indica width y height \(o aspect-ratio\) en cada imagen.
  - [movil] html &gt; body &gt; div.wrap:nth-of-type\(1\) &gt; img:nth-of-type\(2\): «wAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw==» sin width/height
  - [escritorio] html &gt; body &gt; div.wrap:nth-of-type\(1\) &gt; img:nth-of-type\(2\): «wAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw==» sin width/height
- **[Media] VIS-EMOJI-ICONOS · Iconos SVG en lugar de emojis** — No cumple (58 de 64 elementos correctos)
  - Norma: Guía UI UX Pro Max \(no emoji icons\)
  - Cómo corregirlo: Usa iconos SVG coherentes \(Lucide, Heroicons, Phosphor\).
  - [movil] html &gt; body &gt; div.wrap:nth-of-type\(1\) &gt; h4: «🚀 Bienvenido»
  - [movil] html &gt; body &gt; div.wrap:nth-of-type\(1\) &gt; button:nth-of-type\(1\): «✖»
  - [movil] html &gt; body &gt; div.wrap:nth-of-type\(1\) &gt; button.icon:nth-of-type\(2\): «❤️»
  - [escritorio] html &gt; body &gt; div.wrap:nth-of-type\(1\) &gt; h4: «🚀 Bienvenido»
  - [escritorio] html &gt; body &gt; div.wrap:nth-of-type\(1\) &gt; button:nth-of-type\(1\): «✖»
- **[Media] VIS-INTERLINEADO · Interlineado legible \(≥ 1,4\)** — No cumple (0 de 2 elementos correctos)
  - Norma: WCAG 2.2 · 1.4.12 Espaciado del texto \(referencia\)
  - Cómo corregirlo: line-height entre 1,4 y 1,6 en párrafos.
  - [movil] html &gt; body &gt; div.wrap:nth-of-type\(1\) &gt; p.gris:nth-of-type\(1\): interlineado 1.00: «Este texto gris claro tiene muy poco con»
  - [escritorio] html &gt; body &gt; div.wrap:nth-of-type\(1\) &gt; p.gris:nth-of-type\(1\): interlineado 1.00: «Este texto gris claro tiene muy poco con»
- **[Media] VIS-TEXTO-BASE · Tamaño base del texto en móvil \(≥ 16 px\)** — No cumple (texto base 13.0 px)
  - Norma: Material Design · Apple HIG · Guía UI UX Pro Max
  - Cómo corregirlo: Texto de lectura de 16 px como mínimo en móvil.
  - [movil] body: Tamaño de texto predominante 13.0 px
- **[Media] FORM-AUTOCOMPLETE · Autocompletado en datos personales** — No cumple (0 de 4 elementos correctos)
  - Norma: WCAG 2.2 · 1.3.5 Identificar el propósito de la entrada
  - Cómo corregirlo: Añade autocomplete="email", "name", "tel", "current-password"…
  - [movil] html &gt; body &gt; div.wrap:nth-of-type\(1\) &gt; form &gt; input:nth-of-type\(1\): autocomplete="off"
  - [movil] html &gt; body &gt; div.wrap:nth-of-type\(1\) &gt; form &gt; input:nth-of-type\(2\): falta autocomplete="current-password"
  - [escritorio] html &gt; body &gt; div.wrap:nth-of-type\(1\) &gt; form &gt; input:nth-of-type\(1\): autocomplete="off"
  - [escritorio] html &gt; body &gt; div.wrap:nth-of-type\(1\) &gt; form &gt; input:nth-of-type\(2\): falta autocomplete="current-password"
- **[Media] FORM-GRUPOS · Grupos de opciones con leyenda** — No cumple (0 de 2 elementos correctos)
  - Norma: WCAG 2.2 · 1.3.1 · GOV.UK
  - Cómo corregirlo: Agrupa radios y casillas en &lt;fieldset&gt; con &lt;legend&gt;.
  - [movil] html &gt; body &gt; div.wrap:nth-of-type\(1\) &gt; form &gt; input:nth-of-type\(3\): grupo «plan» \(2 opciones\) sin fieldset/legend
  - [escritorio] html &gt; body &gt; div.wrap:nth-of-type\(1\) &gt; form &gt; input:nth-of-type\(3\): grupo «plan» \(2 opciones\) sin fieldset/legend
- **[Media] FORM-TIPO-ENTRADA · Tipo de campo adecuado \(teclado móvil\)** — No cumple (0 de 2 elementos correctos)
  - Norma: Guía UI UX Pro Max \(Input Types / Mobile Keyboards\)
  - Cómo corregirlo: Usa type="email", type="tel" o inputmode="numeric" para mostrar el teclado correcto.
  - [movil] html &gt; body &gt; div.wrap:nth-of-type\(1\) &gt; form &gt; input:nth-of-type\(1\): type="text" para un dato tipo email \(usa type="email"\)
  - [escritorio] html &gt; body &gt; div.wrap:nth-of-type\(1\) &gt; form &gt; input:nth-of-type\(1\): type="text" para un dato tipo email \(usa type="email"\)
- **[Media] NAV-ANCLAS-ROTAS · Enlaces internos con destino válido** — No cumple (0 de 36 elementos correctos)
  - Norma: HTML · Nielsen H4
  - Cómo corregirlo: Que cada href="\#id" apunte a un id existente; usa &lt;button&gt; para acciones.
  - [movil] div.wrap:nth-of-type\(1\) &gt; nav &gt; ul &gt; li:nth-of-type\(1\) &gt; a: href="\#" \(falso enlace: usa &lt;button&gt;\)
  - [movil] div.wrap:nth-of-type\(1\) &gt; nav &gt; ul &gt; li:nth-of-type\(2\) &gt; a: href="\#" \(falso enlace: usa &lt;button&gt;\)
  - [movil] div.wrap:nth-of-type\(1\) &gt; nav &gt; ul &gt; li:nth-of-type\(3\) &gt; a: href="\#" \(falso enlace: usa &lt;button&gt;\)
  - [movil] div.wrap:nth-of-type\(1\) &gt; nav &gt; ul &gt; li:nth-of-type\(4\) &gt; a: href="\#" \(falso enlace: usa &lt;button&gt;\)
  - [movil] div.wrap:nth-of-type\(1\) &gt; nav &gt; ul &gt; li:nth-of-type\(5\) &gt; a: href="\#" \(falso enlace: usa &lt;button&gt;\)
- **[Media] NAV-BARRA-INFERIOR · Barra inferior móvil con ≤ 5 opciones** — No cumple (0 de 1 elementos correctos)
  - Norma: Material Design \(navigation bar 3–5\) · Apple HIG \(tab bar\)
  - Cómo corregirlo: Entre 3 y 5 destinos en la barra inferior.
  - [movil] html &gt; body &gt; div.sticky:nth-of-type\(2\): 7 opciones en la barra inferior
- **[Media] NAV-LANDMARKS · Regiones principales \(main, nav\)** — No cumple (2 de 4 elementos correctos)
  - Norma: WCAG 2.2 · 1.3.1 / 2.4.1 · WAI-ARIA landmarks
  - Cómo corregirlo: Un único &lt;main&gt; y la navegación dentro de &lt;nav&gt;.
  - [movil] html &gt; body: no hay &lt;main&gt;
  - [escritorio] html &gt; body: no hay &lt;main&gt;
- **[Media] NAV-MENU · Menús de navegación de tamaño razonable \(≤ 7\)** — No cumple (0 de 1 elementos correctos)
  - Norma: Ley de Hick-Hyman · ley de Miller
  - Cómo corregirlo: Como máximo 7 opciones en el primer nivel; agrupa el resto.
  - [escritorio] html &gt; body &gt; div.wrap:nth-of-type\(1\) &gt; nav: 9 opciones en el primer nivel
- **[Media] NAV-TEXTO-ENLACES · Texto de enlace descriptivo** — No cumple (32 de 38 elementos correctos)
  - Norma: WCAG 2.2 · 2.4.4 Propósito de los enlaces
  - Cómo corregirlo: El texto del enlace dice adónde lleva \(«Ver la carta de postres»\).
  - [movil] html &gt; body &gt; div.wrap:nth-of-type\(1\) &gt; a:nth-of-type\(1\): texto genérico «haz clic aquí»
  - [movil] html &gt; body &gt; div.wrap:nth-of-type\(1\) &gt; a:nth-of-type\(2\): texto genérico «ver más»
  - [movil] html &gt; body &gt; div.wrap:nth-of-type\(1\) &gt; a:nth-of-type\(3\): texto genérico «leer más»
  - [escritorio] html &gt; body &gt; div.wrap:nth-of-type\(1\) &gt; a:nth-of-type\(1\): texto genérico «haz clic aquí»
  - [escritorio] html &gt; body &gt; div.wrap:nth-of-type\(1\) &gt; a:nth-of-type\(2\): texto genérico «ver más»
- **[Baja] INT-CURSOR · Cursor de mano en elementos clicables** — No cumple (19 de 21 elementos correctos)
  - Norma: Guía UI UX Pro Max \(cursor-pointer\)
  - Cómo corregirlo: Aplica cursor:pointer a botones y controles clicables.
  - [escritorio] html &gt; body &gt; div.wrap:nth-of-type\(1\) &gt; button:nth-of-type\(1\): cursor: default en «✖»
  - [escritorio] html &gt; body &gt; div.wrap:nth-of-type\(1\) &gt; button.icon:nth-of-type\(2\): cursor: default en «❤️»
- **[Baja] VIS-FUENTES · Número de familias tipográficas \(≤ 3\)** — No cumple (5 familias: comic sans ms, arial, impact, georgia, verdana)
  - Norma: Sistemas de diseño · consistencia \(Nielsen H4\)
  - Cómo corregirlo: Una o dos familias \(títulos y texto\) más, como mucho, una monoespaciada.
  - [movil] body: comic sans ms, arial, impact, georgia, verdana
  - [escritorio] body: comic sans ms, arial, impact, georgia, verdana
- **[Baja] FORM-ENVIO · Formularios con botón de envío** — No cumple (0 de 2 elementos correctos)
  - Norma: Heurística Nielsen H1 · HTML
  - Cómo corregirlo: Incluye un botón de envío explícito \(&lt;button type="submit"&gt;\).
  - [movil] html &gt; body &gt; div.wrap:nth-of-type\(1\) &gt; form: formulario sin botón de envío
  - [escritorio] html &gt; body &gt; div.wrap:nth-of-type\(1\) &gt; form: formulario sin botón de envío
- **[Baja] NAV-NUEVA-VENTANA · Aviso al abrir en nueva pestaña** — No cumple (0 de 2 elementos correctos)
  - Norma: WCAG 2.2 · 3.2.5 \(AAA\) · Nielsen H3
  - Cómo corregirlo: Indica «\(se abre en una pestaña nueva\)» en el texto, aria-label o con un icono etiquetado.
  - [movil] html &gt; body &gt; div.wrap:nth-of-type\(1\) &gt; a:nth-of-type\(3\): «leer más» se abre en otra pestaña sin avisar
  - [escritorio] html &gt; body &gt; div.wrap:nth-of-type\(1\) &gt; a:nth-of-type\(3\): «leer más» se abre en otra pestaña sin avisar
- **[Alta] A11Y-CONTRASTE · Contraste de color del texto** — Cumple parcialmente (50 de 52 elementos correctos)
  - Norma: WCAG 2.2 · 1.4.3 Contraste \(mínimo\)
  - Cómo corregirlo: Asegura un contraste de al menos 4,5:1 en texto normal y 3:1 en texto grande \(≥ 24 px o ≥ 18,66 px en negrita\).
  - [movil] .gris: Elements must meet minimum color contrast ratio thresholds — Fix any of the following: Element has insufficient color contrast of 1.91 \(foreground color: \#bbbbbb, background color: \#ffffff, font size: 9.8pt \(13px\), font weight: normal\). Expected contrast ratio…
  - [escritorio] .gris: Elements must meet minimum color contrast ratio thresholds — Fix any of the following: Element has insufficient color contrast of 1.91 \(foreground color: \#bbbbbb, background color: \#ffffff, font size: 9.8pt \(13px\), font weight: normal\). Expected contrast ratio…
- **[Alta] A11Y-ESPACIADO-TEXTO · Soporta el espaciado de texto del usuario** — Cumple parcialmente (56 de 58 elementos correctos)
  - Norma: WCAG 2.2 · 1.4.12 Espaciado del texto \(AA\)
  - Cómo corregirlo: Usa alturas automáticas \(min-height en lugar de height\) para que el texto pueda crecer sin cortarse con interlineado 1,5, espaciado entre letras 0,12 em, entre palabras 0,16 em y entre párrafos 2 em.
  - [movil] html &gt; body &gt; div.wrap:nth-of-type\(1\) &gt; button.icon:nth-of-type\(2\): texto cortado o solapado: 19px de contenido en 12px \(«❤️»\)
  - [escritorio] html &gt; body &gt; div.wrap:nth-of-type\(1\) &gt; button.icon:nth-of-type\(2\): texto cortado o solapado: 19px de contenido en 12px \(«❤️»\)
- **[Alta] SAT-SUS · Satisfacción de usuarios \(SUS\)** — Cumple parcialmente (SUS 81.5/100 \(5 participantes\))
  - Norma: SUS \(Brooke\) · ISO 9241-11 satisfacción
  - Cómo corregirlo: Prueba con al menos 5 usuarios; una puntuación SUS ≥ 68 está por encima de la media.
- **[Media] NAV-TITULO · Título de página descriptivo** — Cumple parcialmente («Document» \(8 caracteres\))
  - Norma: WCAG 2.2 · 2.4.2 Titulado de páginas
  - Cómo corregirlo: Título único y descriptivo de 10–70 caracteres \(«Reservas · Restaurante Mar»\).
  - [movil] title: «Document»: genérico o de longitud inadecuada
  - [escritorio] title: «Document»: genérico o de longitud inadecuada

> ℹ️ Reglas manuales sin evaluar: MAN-AYUDA, MAN-CANCELACION, MAN-CONSISTENCIA, MAN-CONTENIDO-HOVER, MAN-CONTROL-LIBERTAD, MAN-COSTES-OCULTOS, MAN-ESTADO-SISTEMA, MAN-FLEXIBILIDAD, MAN-GESTION-FOCO, MAN-HOVER, MAN-IA-TRANSPARENCIA, MAN-KRUG-BUENA-VOLUNTAD, MAN-KRUG-EVIDENTE, MAN-KRUG-PORTADA, MAN-KRUG-PRUEBAS, MAN-MINIMALISMO, MAN-MUNDO-REAL, MAN-PREVENCION-ERRORES, MAN-RECONOCER, MAN-RECUPERACION-ERRORES, MAN-RESUMEN-ERRORES. Ejecuta `uxaudit manual` para completarlas.

